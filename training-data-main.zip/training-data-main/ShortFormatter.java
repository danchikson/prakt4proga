
public class ShortFormatter {

    public static final ShortFormatter ISO_DATE_TIME = null;

}
